"use strict";
const platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
const app_1 = require('./app');
platform_browser_dynamic_1.bootstrap(app_1.AppComponent);
//# sourceMappingURL=main.js.map